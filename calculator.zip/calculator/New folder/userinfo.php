<?php
$servername= "localhost";
$username= "root";
$password= "";
$database="websiteuserdata";
$con = mysqli_connect($servername,$username,$password,$database);

if($con){
    echo "Connection successful";
}else{
    echo "No connection";
}

// mysqli_select_db($con, 'websiteuserdata');

$user = $_POST['user'];
$email = $_POST['email'];
 $mobile = $_POST['mobile'];
 $comment = $_POST['comments'];

// $query =  " insert into userinfodata (user, email, mobile, comment)
// values ('$user', '$email', '$mobile', '$comment');"

// mysqli_query($con, $query);
$sql= "INSERT INTO `userinfodata` (`user`, `email`, `mobile`, `comment`) VALUES ( '$user', '$email', '$mobile', '$comment')
";
$result= mysqli_query($con,$sql);
if(!result){
    die("not inserted");
}
else{
    echo"inserted";
}
?>